export default function handler(req,res){ res.json({ ok:true, signatureBase58: '' }) }
