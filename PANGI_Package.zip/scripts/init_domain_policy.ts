// See docs/DomainPolicy_Guide.md; wire your Anchor client to send init_domain_policy.
