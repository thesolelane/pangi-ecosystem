# Platform Authorization (Ed25519)
Updated: 2025-10-03T13:17:21.378607Z
See web/mint-dapp/lib/platformAuth.ts for helpers.
