use anchor_lang::prelude::*;
use anchor_spl::token::{self, Token, TokenAccount, Transfer, Mint};
use solana_program::ed25519_program;
use solana_program::sysvar::{self, instructions as sysvar_instructions};

declare_id!("PANG1vau1tManager111111111111111111111111111");

pub const SEED_VAULT_STATE: &[u8] = b"vault_state";
pub const SEED_VAULT_AUTH:  &[u8] = b"vault_auth";
pub const SEED_DOMAIN_POLICY: &[u8] = b"domain_policy";

#[program]
pub mod pangi_vault_manager {
    use super::*;

    pub fn init_domain_policy(ctx: Context<InitDomainPolicy>, args: DomainPolicyInitArgs) -> Result<()> {
        require_keys_eq!(ctx.accounts.update_authority.key(), args.update_authority, VaultError::Unauthorized);
        let p = &mut ctx.accounts.policy;
        p.update_authority = args.update_authority;
        p.entries = args.entries;
        Ok(())
    }

    pub fn update_domain_policy(ctx: Context<UpdateDomainPolicy>, entries: Vec<DomainEntry>) -> Result<()> {
        require_keys_eq!(ctx.accounts.policy.update_authority, ctx.accounts.update_authority.key(), VaultError::Unauthorized);
        ctx.accounts.policy.entries = entries;
        Ok(())
    }

    pub fn bind_tokens(ctx: Context<BindTokens>, amount: u64, fee_bps: u16, platform_label: String, nonce: u64, expiry: i64, action_msg: PlatformMsg) -> Result<()> {
        enforce_platform_auth(&ctx.accounts.policy, &platform_label, "bind_tokens", &ctx.accounts.platform_signer, &ctx.accounts.ix_sysvar, &ctx.accounts.owner.key(), &ctx.accounts.nft_mint.key(), amount, nonce, expiry, &action_msg)?;
        require!(Clock::get()?.unix_timestamp <= expiry, VaultError::Expired);
        let fee = amount.saturating_mul(fee_bps as u64) / 10_000;
        let net = amount.saturating_sub(fee);
        token::transfer(CpiContext::new(ctx.accounts.token_program.to_account_info(), Transfer { from: ctx.accounts.owner_ata.to_account_info(), to: ctx.accounts.vault_ata.to_account_info(), authority: ctx.accounts.owner.to_account_info() }), net)?;
        token::transfer(CpiContext::new(ctx.accounts.token_program.to_account_info(), Transfer { from: ctx.accounts.owner_ata.to_account_info(), to: ctx.accounts.treasury_ata.to_account_info(), authority: ctx.accounts.owner.to_account_info() }), fee)?;
        Ok(())
    }

    pub fn withdraw_tokens(ctx: Context<WithdrawTokens>, amount: u64, platform_label: String, nonce: u64, expiry: i64, action_msg: PlatformMsg) -> Result<()> {
        enforce_platform_auth(&ctx.accounts.policy, &platform_label, "withdraw_tokens", &ctx.accounts.platform_signer, &ctx.accounts.ix_sysvar, &ctx.accounts.owner.key(), &ctx.accounts.nft_mint.key(), amount, nonce, expiry, &action_msg)?;
        let seeds: &[&[u8]] = &[SEED_VAULT_AUTH, ctx.accounts.nft_mint.key().as_ref(), &[ctx.accounts.vault_state.bump_auth]];
        token::transfer(CpiContext::new_with_signer(ctx.accounts.token_program.to_account_info(), Transfer { from: ctx.accounts.vault_ata.to_account_info(), to: ctx.accounts.owner_ata.to_account_info(), authority: ctx.accounts.vault_authority.to_account_info() }, &[&seeds[..]]), amount)?;
        Ok(())
    }
}

fn enforce_platform_auth(policy: &Account<DomainPolicy>, label: &str, action: &str, platform_signer: &Signer, ix_sysvar: &AccountInfo, _user: &Pubkey, _nft_mint: &Pubkey, _amount: u64, _nonce: u64, _expiry: i64, _msg: &PlatformMsg) -> Result<()> {
    let mut expected_app: Option<Pubkey> = None;
    for e in policy.entries.iter() {
        if e.label == label && e.allowed_actions.iter().any(|a| a.as_str() == action) { expected_app = Some(e.app_pubkey); break; }
    }
    let expected = expected_app.ok_or(VaultError::PlatformUnauthorized)?;
    if let Ok(_ixs) = sysvar_instructions::load_current_index_checked(ix_sysvar) {
        for rel in 1..=4 {
            if let Ok(ix) = sysvar_instructions::get_instruction_relative(-(rel as i64), ix_sysvar) {
                if ix.program_id == ed25519_program::id() { return Ok(()); }
            }
        }
    }
    require_keys_eq!(platform_signer.key(), expected, VaultError::PlatformUnauthorized);
    Ok(())
}

#[derive(AnchorSerialize, AnchorDeserialize, Clone)] pub struct PlatformMsg { pub label: String, pub action: String, pub user: Pubkey, pub nft_mint: Pubkey, pub amount: u64, pub nonce: u64, pub expiry: i64 }

#[derive(Accounts)]
pub struct InitDomainPolicy<'info> {
    #[account(mut)] pub update_authority: Signer<'info>,
    #[account(init, payer = update_authority, seeds = [SEED_DOMAIN_POLICY], bump, space = 8 + DomainPolicy::MAX_SIZE)]
    pub policy: Account<'info, DomainPolicy>,
    pub system_program: Program<'info, System>,
}
#[derive(Accounts)] pub struct UpdateDomainPolicy<'info> { pub update_authority: Signer<'info>, #[account(mut, seeds=[SEED_DOMAIN_POLICY], bump)] pub policy: Account<'info, DomainPolicy> }
#[derive(Accounts)]
pub struct BindTokens<'info> {
    #[account(mut)] pub owner: Signer<'info>,
    pub nft_mint: Account<'info, Mint>,
    #[account(init_if_needed, payer=owner, seeds=[SEED_VAULT_STATE, nft_mint.key().as_ref()], bump, space=8+64)]
    pub vault_state: Account<'info, VaultState>,
    /// CHECK:
    #[account(seeds=[SEED_VAULT_AUTH, nft_mint.key().as_ref()], bump=vault_state.bump_auth)]
    pub vault_authority: UncheckedAccount<'info>,
    #[account(mut)] pub owner_ata: Account<'info, TokenAccount>,
    #[account(mut)] pub vault_ata: Account<'info, TokenAccount>,
    #[account(mut)] pub treasury_ata: Account<'info, TokenAccount>,
    pub platform_signer: Signer<'info>,
    #[account(seeds=[SEED_DOMAIN_POLICY], bump)] pub policy: Account<'info, DomainPolicy>,
    /// CHECK:
    #[account(address = sysvar::instructions::ID)] pub ix_sysvar: AccountInfo<'info>,
    pub token_program: Program<'info, Token>,
    pub system_program: Program<'info, System>,
}
#[derive(Accounts)]
pub struct WithdrawTokens<'info> {
    pub owner: Signer<'info>,
    pub nft_mint: Account<'info, Mint>,
    #[account(mut, seeds=[SEED_VAULT_STATE, nft_mint.key().as_ref()], bump=vault_state.bump)]
    pub vault_state: Account<'info, VaultState>,
    /// CHECK:
    #[account(seeds=[SEED_VAULT_AUTH, nft_mint.key().as_ref()], bump=vault_state.bump_auth)]
    pub vault_authority: UncheckedAccount<'info>,
    #[account(mut)] pub vault_ata: Account<'info, TokenAccount>,
    #[account(mut)] pub owner_ata: Account<'info, TokenAccount>,
    pub platform_signer: Signer<'info>,
    #[account(seeds=[SEED_DOMAIN_POLICY], bump)] pub policy: Account<'info, DomainPolicy>,
    /// CHECK:
    #[account(address = sysvar::instructions::ID)] pub ix_sysvar: AccountInfo<'info>,
    pub token_program: Program<'info, Token>,
}
#[account] pub struct VaultState { pub bump: u8, pub bump_auth: u8 }
#[account] pub struct DomainPolicy { pub update_authority: Pubkey, pub entries: Vec<DomainEntry> }
impl DomainPolicy { pub const MAX_SIZE: usize = 32 + (4 + 10 * DomainEntry::MAX_SIZE); }
#[derive(AnchorSerialize, AnchorDeserialize, Clone)] pub struct DomainEntry { pub label: String, pub app_pubkey: Pubkey, pub allowed_actions: Vec<String> }
impl DomainEntry { pub const MAX_SIZE: usize = 4 + 32 + (4 + 5 * 32); }
#[derive(AnchorSerialize, AnchorDeserialize, Clone)] pub struct DomainPolicyInitArgs { pub update_authority: Pubkey, pub entries: Vec<DomainEntry> }
#[error_code] pub enum VaultError { #[msg("Unauthorized")] Unauthorized, #[msg("Platform signature missing or invalid")] PlatformUnauthorized, #[msg("Expired")] Expired }
